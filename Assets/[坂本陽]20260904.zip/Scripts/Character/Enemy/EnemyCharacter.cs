public class EnemyCharacter : CharacterBase
{
}
